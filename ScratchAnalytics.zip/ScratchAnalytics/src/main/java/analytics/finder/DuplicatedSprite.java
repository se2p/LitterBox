package analytics.finder;

import analytics.Issue;
import analytics.IssueFinder;
import scratch2.data.Script;
import scratch2.structure.Project;
import scratch2.structure.Scriptable;

import java.util.*;

public class DuplicatedSprite implements IssueFinder {

    @Override
    public Issue check(Project project) {
        List<Scriptable> scriptables = new ArrayList<>();
        scriptables.add(project.getStage());
        scriptables.addAll(project.getSprites());
        int count = 0;
        List<String> pos = new ArrayList<>();
        Map<String, List<String>> scriptMap = new HashMap<>();
        for (Scriptable scable : scriptables) {
            scriptMap.put(scable.getName(), new ArrayList<>());
            for (Script script : scable.getScripts()) {
                if (script != null) {
                    scriptMap.get(scable.getName()).add(script.toString());
                }
            }
        }
        for (String check : scriptMap.keySet()) {
            for (String check2 : scriptMap.keySet()) {
                if (!check.equals(check2)) {
                    if (equalLists(scriptMap.get(check), scriptMap.get(check2))) {
                        if (!pos.contains(check2 + " and " + check)) {
                            pos.add(check + " and " + check2);
                        }
                    }
                }
            }
        }
        count = pos.size();
        String notes = "There are no duplicated sprites in your project.";
        if (count > 0) {
            notes = "There are duplicated sprites in your project.";
        }

        String name = "duplicated_sprite";
        return new Issue(name, count, pos, project.getPath(), notes);
    }

    public boolean equalLists(List<String> one, List<String> two) {
        if (one == null && two == null) {
            return true;
        }

        if (one == null || two == null || one.size() != two.size()) {
            return false;
        }

        one = new ArrayList<String>(one);
        two = new ArrayList<String>(two);

        Collections.sort(one);
        Collections.sort(two);
        return one.equals(two);
    }

}
