package utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Date;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipReader {

    private static final String FILE_PATH = "C:\\scratchprojects\\files\\";

    public static void readFile(String path) throws IOException {
        final ZipFile file = new ZipFile(path);
        System.out.println("Iterating over zip file : " + path);
        try {
            final Enumeration<? extends ZipEntry> entries = file.entries();
            while (entries.hasMoreElements()) {
                final ZipEntry entry = entries.nextElement();
                //System.out.printf("File: %s Size %d Modified on %TD %n", entry.getName(), entry.getSize(), new Date(entry.getTime()));
            }
        } finally {
            file.close();
        }
    }

    public static String getName(String path) throws IOException {
        final ZipFile file = new ZipFile(path);
        return file.getName();
    }

    static String getJson(String path) throws IOException {
        final ZipFile file = new ZipFile(path);
        try {
            final Enumeration<? extends ZipEntry> entries = file.entries();
            while (entries.hasMoreElements()) {
                final ZipEntry entry = entries.nextElement();
                if (entry.getName().equals("project.json")) {
                    InputStream is = file.getInputStream(entry);
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line);        //.append('\n');
                    }
                    return sb.toString();
                }
            }
        } finally {
            file.close();
        }
        return null;
    }

    static String getJsonRAW(String path) {
        StringBuilder sb = new StringBuilder();
        try {
            InputStream is = new URL(FILE_PATH + path).openStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);        //.append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return sb.toString();
    }

    public static String getPath(String path) {
        return (path);
    }
}
