package utils.deserializer;

import com.fasterxml.jackson.databind.JsonNode;
import scratch2.data.ScBlock;
import scratch2.data.Script;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ScriptDeserializer {

    public static List<Script> deserialize(JsonNode rootNode) {
        JsonNode globalScripts = rootNode.path("scripts");
        Iterator<JsonNode> elements = globalScripts.elements();
        List<Script> scripts = new ArrayList<>();
        while (elements.hasNext()) {
            JsonNode c = elements.next();
            List<String> scrpt = new ArrayList<>();
            List<ScBlock> blocks = new ArrayList<>();
            if (c.isArray()) {
                for (final JsonNode objNode : c) {
                    if (objNode.isArray()) {
                        blocks = parseBlocks(objNode);
                    } else {
                        scrpt.add(objNode.asText());
                    }
                }
            }
            Script script = new Script();
            double[] pos = {Double.valueOf(scrpt.get(0)), Double.valueOf(scrpt.get(1))};
            script.setPosition(pos);
            script.setBlocks(blocks);
            scripts.add(script);
        }
        return scripts;
    }

    private static List<ScBlock> parseBlocks(JsonNode objectNode) {
        List<ScBlock> blocks = new ArrayList<>();
        if (objectNode.isArray()) {
            for (final JsonNode node : objectNode) {
                ScBlock bl = parseBlock2(node);
                blocks.add(bl);
            }
        }
        return blocks;
    }

    @Deprecated
    private static ScBlock parseBlock(JsonNode objectNode) {
        ScBlock bl = new ScBlock();
        if (objectNode.size() == 3) {
            bl.setContent(objectNode.get(0).asText());
            //bl.setInnerBlock(parseBlock(objectNode.get(1)));
            bl.setNestedBlocks(parseBlocks(objectNode.get(2)));
        } else if (objectNode.size() == 2) {
            if (!objectNode.get(1).isArray()) {
                bl.setContent(objectNode.get(0).asText() + " " + objectNode.get(1).asText());
            } else {
                bl.setContent(objectNode.get(0).asText());
                bl.setNestedBlocks(parseBlocks(objectNode.get(1)));
            }
        } else if (objectNode.size() == 1) {
            bl.setContent(objectNode.get(0).asText());
        }
        return bl;
    }

    private static ScBlock parseBlock2(JsonNode objectNode) {
        ScBlock bl = new ScBlock();
        if (objectNode.size() == 1) {
            bl.setContent(objectNode.get(0).asText());
            return bl;
        } else if (objectNode.size() == 4){
            //System.out.println(objectNode);
            bl.setContent(objectNode.get(0).asText());
            //System.out.println(objectNode);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < objectNode.size(); i++) {
                //System.out.println(objectNode.get(i));
                if (objectNode.get(i).isArray()) {
                    if (objectNode.get(i).get(0) != null && objectNode.get(i).get(0).isArray()) {
                        if (i == 2) {
                            bl.setNestedBlocks(parseBlocks(objectNode.get(i)));
                        } else {
                            bl.setElseBlocks(parseBlocks(objectNode.get(i)));
                        }
                    } else {
                        sb.append(objectNode.get(i));
                    }
                } else {
                    sb.append(objectNode.get(i));
                }
            }
            bl.setContent(sb.toString());
        } else if (objectNode.size() > 1) {
            bl.setContent(objectNode.get(0).asText());
            //System.out.println(objectNode);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < objectNode.size(); i++) {
                //System.out.println(objectNode.get(i));
                if (objectNode.get(i).isArray()) {
                    if (objectNode.get(i).get(0) != null && objectNode.get(i).get(0).isArray()) {
                        bl.setNestedBlocks(parseBlocks(objectNode.get(i)));
                    } else {
                        sb.append(objectNode.get(i));
                    }
                } else {
                    sb.append(objectNode.get(i));
                }
            }
            bl.setContent(sb.toString());
        }
        return bl;
    }

}
