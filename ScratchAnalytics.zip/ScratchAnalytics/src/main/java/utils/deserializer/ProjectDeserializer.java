package utils.deserializer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import scratch2.structure.Project;

import java.io.IOException;

public class ProjectDeserializer extends StdDeserializer<Project> {

    public ProjectDeserializer() {
        this(null);
    }

    public ProjectDeserializer(Class<?> vc) {
        super(vc);
    }

    public Project deserialize(com.fasterxml.jackson.core.JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        JsonNode rootNode = jp.getCodec().readTree(jp);
        Project project = new Project();
        project.setName(rootNode.get("objName").asText());
        return project;
    }
}