package utils.deserializer;

import com.fasterxml.jackson.databind.JsonNode;
import scratch2.data.Costume;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CostumeDeserializer {

    public static List<Costume> deserialize(JsonNode rootNode) {
        JsonNode globalVariables = rootNode.path("costumes");
        Iterator<JsonNode> elements = globalVariables.elements();
        List<Costume> costumes = new ArrayList<Costume>();
        while (elements.hasNext()) {
            JsonNode variable = elements.next();
            Costume scCostume = new Costume();
            scCostume.setName(variable.get("costumeName").asText());
            scCostume.setBaseLayerID(variable.get("baseLayerID").asInt());
            costumes.add(scCostume);
        }
        return costumes;
    }
}
