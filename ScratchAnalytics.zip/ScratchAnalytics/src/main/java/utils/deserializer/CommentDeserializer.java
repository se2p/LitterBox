package utils.deserializer;

import com.fasterxml.jackson.databind.JsonNode;
import scratch2.data.Comment;
import scratch2.data.ScList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A comment tuple stores a comment as a JSON array.
 * Each comment is an array of length seven,
 * in the form [x, y, width, height, isOpen, blockID, text].
 */
public class CommentDeserializer {

    public static List<Comment> deserialize(JsonNode rootNode) {
        JsonNode globalComments = rootNode.path("scriptComments");
        Iterator<JsonNode> elements = globalComments.elements();
        List<Comment> comments = new ArrayList<Comment>();
        while (elements.hasNext()) {
            JsonNode c = elements.next();
            List<String> comm = new ArrayList<>();
            if (c.isArray()) {
                for (final JsonNode objNode : c) {
                    comm.add(objNode.asText());
                }
            }
            Comment comment = new Comment();
            comment.setContent(comm.get(6));
            double[] pos = {Double.valueOf(comm.get(0)), Double.valueOf(comm.get(1))};
            comment.setPosition(pos);
            comments.add(comment);
        }
        return comments;
    }

}
