package utils.deserializer;

import com.fasterxml.jackson.databind.JsonNode;
import scratch2.data.*;
import scratch2.structure.Sprite;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SpriteDeserializer {

    public static List<Sprite> deserialize(JsonNode rootNode) {
        List<Sprite> sprites = new ArrayList<>();
        JsonNode globalSprites = rootNode.path("children");
        Iterator<JsonNode> elements = globalSprites.elements();
        while (elements.hasNext()) {
            JsonNode c = elements.next();
            if(c.has("objName")) {
                String name = c.get("objName").asText();
                List<Script> scripts = ScriptDeserializer.deserialize(c);
                List<Comment> comments = CommentDeserializer.deserialize(c);
                List<ScVariable> variables = VariableListDeserializer.deserialize(c);
                List<ScList> lists = ListDeserializer.deserialize(c);
                List<Costume> costumes = CostumeDeserializer.deserialize(c);
                List<Sound> sounds = SoundDeserializer.deserialize(c);
                int initCostume = c.get("currentCostumeIndex").asInt();
                double[] position = {c.get("scratchX").asInt(), c.get("scratchY").asInt()};
                double rotation = c.get("direction").asDouble();
                String rotationStyle = c.get("rotationStyle").asText();
                int size = c.get("scale").asInt();
                boolean isVisible = c.get("visible").asBoolean();
                sprites.add(new Sprite(name, scripts, comments, variables, lists, costumes, sounds,
                        initCostume, position, rotation, rotationStyle, size, isVisible));
            }
        }

        return sprites;
    }

}
