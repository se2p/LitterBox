package utils.deserializer;

import com.fasterxml.jackson.databind.JsonNode;
import scratch2.data.Sound;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SoundDeserializer {

    public static List<Sound> deserialize(JsonNode rootNode) {
        JsonNode globalVariables = rootNode.path("sounds");
        Iterator<JsonNode> elements = globalVariables.elements();
        List<Sound> sounds = new ArrayList<Sound>();
        while (elements.hasNext()) {
            JsonNode variable = elements.next();
            Sound scSound = new Sound();
            scSound.setName(variable.get("soundName").asText());
            scSound.setSoundId(variable.get("soundID").asInt());
            sounds.add(scSound);
        }
        return sounds;
    }
}
