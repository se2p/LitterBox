import analytics.IssueTool;
import org.apache.commons.csv.CSVPrinter;
import scratch2.structure.Project;
import utils.CSVWriter;
import utils.JsonParser;

import java.io.File;
import java.io.IOException;
import java.nio.file.NoSuchFileException;
import java.util.Objects;

public class Main {

    private final static File folder = new File("C:\\scratchprojects\\files\\");

    public static void main(String[] args) {
        CSVPrinter printer = null;
        try {
            String name = "./dataset0.csv";
            Project project = null;
            int count = 0;
            int datacount = 0;
            printer = CSVWriter.getNewPrinter(name);
            for (final File fileEntry : Objects.requireNonNull(folder.listFiles())) {
                if (!fileEntry.isDirectory()) {
                    System.out.println(fileEntry);
                    try {
                        project = JsonParser.parseRaw(fileEntry);
                    } catch (Exception e) {
                        if (e instanceof NoSuchFileException) {
                            System.out.println("No file found for: " + ((NoSuchFileException) e).getFile());
                        } else {
                            e.printStackTrace();
                        }
                    }
                    if (project != null) {
                        //System.out.println(project.toString());
                        IssueTool iT = new IssueTool();
                        iT.check(project, printer, name);
                        count++;
                    }
                }
                if (count == 1) {
                    if (count == folder.listFiles().length - 1 || datacount == 1) {
                        CSVWriter.flushCSV(printer);
                        return;
                    }
                    CSVWriter.flushCSV(printer);
                    count = 0;
                    System.out.println("Finished: " + name);
                    datacount++;
                    name = "./dataset" + datacount + ".csv";
                    printer = CSVWriter.getNewPrinter(name);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main2(String[] args) {
        CSVPrinter printer = null;
        try {
            String name = "./test.csv";
            Project project = null;
            printer = CSVWriter.getNewPrinter(name);
            for (final File fileEntry : Objects.requireNonNull(folder.listFiles())) {
                if (!fileEntry.isDirectory() && fileEntry.getName().startsWith("FS_013")) {
                    System.out.println(fileEntry);
                    System.out.println(fileEntry.getName());
                    try {
                        project = JsonParser.parse(fileEntry.getName(), fileEntry.getPath());
                    } catch (Exception e) {
                        if (e instanceof NoSuchFileException) {
                            System.out.println("No file found for: " + ((NoSuchFileException) e).getFile());
                        } else {
                            e.printStackTrace();
                        }
                    }
                    assert project != null;
                    //System.out.println(project.toString());
                    IssueTool iT = new IssueTool();
                    iT.check(project, printer, name);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                CSVWriter.flushCSV(printer);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
