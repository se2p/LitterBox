package scratch2.structure;

import scratch2.data.*;
import utils.JsonParser;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * A scriptable object displayed on the project stage.
 * Sprites require a Costume.
 */
public class Sprite extends Scriptable {

    private double[] position;
    private double rotation;
    private String rotationStyle;
    private int size;
    private boolean isVisible;

    /**
     * @param name          Name of Sprite
     * @param scripts       List containing Scripts
     * @param comments      List containing Comments
     * @param variables     List of ScVariables
     * @param lists         List of ScList
     * @param costumes      List of Costumes
     * @param sounds        List of Sounds
     * @param initCostume   The current selected Costume
     * @param position      Position of Sprite on Stage
     * @param rotation      Rotation of Sprite
     * @param rotationStyle RotationStyle
     * @param size          Scale of Sprite
     * @param isVisible     Visibility of Sprite
     */
    public Sprite(String name, List<Script> scripts, List<Comment> comments, List<ScVariable> variables,
                  List<ScList> lists, List<Costume> costumes, List<Sound> sounds, int initCostume,
                  double[] position, double rotation, String rotationStyle, int size, boolean isVisible) {
        super(name, scripts, comments, variables, lists, costumes, sounds, initCostume);
        this.position = position;
        this.rotation = rotation;
        this.rotationStyle = rotationStyle;
        this.size = size;
        this.isVisible = isVisible;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("---------------------" + "\n");
        sb.append("Name: ").append(this.getName()).append("\n");
        sb.append(JsonParser.prettyPrintScript(this.getScripts())).append("\n");
        sb.append("Comments: ").append(this.getComments()).append("\n");
        sb.append("Variables: ").append(this.getVariables()).append("\n");
        sb.append("Lists: ").append(this.getLists()).append("\n");
        sb.append("Costumes: ").append(this.getCostumes()).append("\n");
        sb.append("Sounds: ").append(this.getSounds()).append("\n");
        sb.append("initCostume: ").append(this.getInitCostume()).append("\n");
        sb.append("Position: ").append(Arrays.toString(this.getPosition())).append("\n");
        sb.append("Rotation: ").append(this.getRotation()).append("\n");
        sb.append("RotationStyle: ").append(this.getRotationStyle()).append("\n");
        sb.append("Scale: ").append(this.getSize()).append("\n");
        sb.append("Visibility: ").append(this.isVisible()).append("\n");
        sb.append("---------------------");
        return sb.toString();
    }

    public double[] getPosition() {
        return position;
    }

    public void setPosition(double[] position) {
        this.position = position;
    }

    public double getRotation() {
        return rotation;
    }

    public void setRotation(double rotation) {
        this.rotation = rotation;
    }

    public String getRotationStyle() {
        return rotationStyle;
    }

    public void setRotationStyle(String rotationStyle) {
        this.rotationStyle = rotationStyle;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean isVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }
}
